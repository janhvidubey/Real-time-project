function validateForm() {
	// Read the form data:-
	var proId = document.getElementById("proId").value;
	var proName = document.getElementById("proName").value;
	var proPrice = document.getElementById("proPrice").value;
	var proBrand = document.getElementById("proBrand").value;
	var proMadeIn = document.getElementById("proMadeIn").value;

	if (proId.trim() === "" || proName.trim() === "" ||
		proPrice.trim() === "" || proBrand.trim() === "" ||
		proMadeIn.trim() === "") {

		alert("All fields must be filed out");
		return false;
		
	}
	if (parseFloat(proPrice) < 0) {
		alert("proPrice must be a non-negative value");
		return false;
	}
	
	if (proName.Length > 50 || proBrand > 50) {
		alert("product name and proBrand must be less than 50 charaters");
		return false;
	}
	// get the mgf and exp dates:-
	var proManufacturingDate = document.getElementById("proManufacturingDate").value;
	var proExpiryDate = document.getElementById("proExpiryDate").value;

	// convert into date formate:-
	var manufacturingDateObj = new Date(proManufacturingDate);
	var expiryDateObj = new Date(proExpiryDate);

	// check the validation of dates:-
	if (manufacturingDateObj > expiryDateObj) {
		alert("manufacturing date cannot be greater than expiry date");
		return false;
	}
	return true;
}





