package com.sathya.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


import org.apache.commons.io.IOUtils;


@WebServlet("/AddProductServlet")
@MultipartConfig
public class AddProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String proId =request.getParameter("proId");
		String proName=request.getParameter("proName");
		
		double proPrice=Double.parseDouble(request.getParameter("proPrice"));
		String proBrand =request.getParameter("proBrand");
		String proMadeIn =request.getParameter("proMadeIn");
		
		Date proManufacturingDate=Date.valueOf(request.getParameter("proManufacturingDate"));
		Date proExpiryDate =Date.valueOf(request.getParameter("proExpiryDate"));
		
		Part part=request.getPart("ProImage");
		InputStream inputStream=part.getInputStream();
	    byte[]proImage=IOUtils.toByteArray(inputStream);
	    System.out.println("Image: "+proImage.toString());

		Part part1=request.getPart("ProAudio");
		InputStream inputStream1=part1.getInputStream();
	    byte[]proAudio=IOUtils.toByteArray(inputStream1);
	    System.out.println("Audio: "+proAudio.toString());

		Part part2=request.getPart("ProVideo");
		InputStream inputStream2=part2.getInputStream();
	    byte[]proVideo=IOUtils.toByteArray(inputStream2);
	    System.out.println("Video: "+proVideo.toString());
	    
		product product=new product();
		product.setProId(proId);
		product.setProName(proName);
		product.setProPrice(proPrice);
		product.setProBrand(proBrand);
		product.setProMadeIn(proMadeIn);
		product.setProManufacturingDate(proManufacturingDate);
		product.setProExpiryDate(proExpiryDate);
		product.setProImage(proImage);
		product.setProAudio(proAudio);
		product.setProVideo(proVideo);
	
		//Giving the product to the layer:-
		ProductDao productDao= new ProductDao();
		   int result=0;
		 
			 try {
				result=productDao.saveproduct(product);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		if(result==1)
			
		{ // to send the data to JSP file add the data into request object:-
			request.setAttribute("SaveResult", result);
//			RequestDispatcher dispatcher=request.getRequestDispatcher("ProductList.jsp");
//			dispatcher.forward(request, response);
			System.out.println("Inserted");
		}
		else 
		{ 
			response.setContentType("text/html");
			PrintWriter writer=response.getWriter();
			writer.println("Data insertion fail check once ....."+result);
			RequestDispatcher dispatcher=request.getRequestDispatcher("add-product.html");
			dispatcher.include(request, response);
		}
			
		}
		
		
		
		
		
	}


