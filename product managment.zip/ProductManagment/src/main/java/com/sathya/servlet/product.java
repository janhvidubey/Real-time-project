package com.sathya.servlet;

import java.util.Arrays;
import java.util.Date;

public class product {
	private String proId;
	private String proName;
	private Double proPrice;
	private String proBrand;
	private String proMadeIn;
	private Date proManufacturingDate;
	private Date proExpiryDate;
	private byte[] proImage;
    private byte[] proAudio;
    private byte[] proVideo;
	public String getProId() {
		return proId;
	}
	public void setProId(String proId) {
		this.proId = proId;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public Double getProPrice() {
		return proPrice;
	}
	public void setProPrice(Double proPrice) {
		this.proPrice = proPrice;
	}
	public String getProBrand() {
		return proBrand;
	}
	public void setProBrand(String proBrand) {
		this.proBrand = proBrand;
	}
	public String getProMadeIn() {
		return proMadeIn;
	}
	public void setProMadeIn(String proMadeIn) {
		this.proMadeIn = proMadeIn;
	}
	public Date getProManufacturingDate() {
		return proManufacturingDate;
	}
	public void setProManufacturingDate(Date proManufacturingDate) {
		this.proManufacturingDate = proManufacturingDate;
	}
	public Date getProExpiryDate() {
		return proExpiryDate;
	}
	public void setProExpiryDate(Date proExpiryDate) {
		this.proExpiryDate = proExpiryDate;
	}
	public byte[] getProImage() {
		return proImage;
	}
	public void setProImage(byte[] proImage) {
		this.proImage = proImage;
	}
	public byte[] getProAudio() {
		return proAudio;
	}
	public void setProAudio(byte[] proAudio) {
		this.proAudio = proAudio;
	}
	public byte[] getProVideo() {
		return proVideo;
	}
	public void setProVideo(byte[] proVideo) {
		this.proVideo = proVideo;
	}
	@Override
	public String toString() {
		return "product [proId=" + proId + ", proName=" + proName + ", proPrice=" + proPrice + ", proBrand=" + proBrand
				+ ", proMadeIn=" + proMadeIn + ", proManufacturingDate=" + proManufacturingDate + ", proExpiryDate="
				+ proExpiryDate + ", proImage=" + Arrays.toString(proImage) + ", proAudio=" + Arrays.toString(proAudio)
				+ ", proVideo=" + Arrays.toString(proVideo) + "]";
	}
	
	
}
    
	