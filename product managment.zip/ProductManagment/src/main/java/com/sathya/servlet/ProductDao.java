package com.sathya.servlet;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductDao {
	public int saveproduct(product product) throws SQLException, ClassNotFoundException {
		// declare the resources :-
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int count = 0;
		try {
			connection = DataBaseUtils.createConnection();
			preparedStatement = connection.prepareStatement("insert into product1_data values(?,?,?,?,?,?,?,?,?,?)");

			preparedStatement.setString(1, product.getProId());
			preparedStatement.setString(2, product.getProName());

			preparedStatement.setDouble(3, product.getProPrice());
			preparedStatement.setString(4, product.getProBrand());
			preparedStatement.setString(5, product.getProMadeIn());

			preparedStatement.setDate(6, (Date) product.getProManufacturingDate());
			preparedStatement.setDate(7, (Date) product.getProExpiryDate());
			preparedStatement.setBytes(8, product.getProImage());
			preparedStatement.setBytes(9, product.getProAudio());
			preparedStatement.setBytes(10, product.getProVideo());

			count = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// Before release the connection check the connection present or not:-
			if (connection != null)
				connection.close();
			if (preparedStatement != null)
				preparedStatement.close();
		}
		return count;

	}
	// ===============================================================================================================================

	// This method will be return all the product details:-
	public List<product> findAll()  {
		List<product> proList = new ArrayList<product>();
		try (Connection connection = DataBaseUtils.createConnection();
				Statement statement = connection.createStatement()) {
			ResultSet resultSet = statement.executeQuery("select*from product1_data");
			while (resultSet.next()) {
				product product = new product();
				product.setProId(resultSet.getString(1));
				product.setProName(resultSet.getString(2));
				product.setProPrice(resultSet.getDouble(3));
				product.setProBrand(resultSet.getString(4));
				product.setProMadeIn(resultSet.getString(5));
				product.setProManufacturingDate(resultSet.getDate(6));
				product.setProExpiryDate(resultSet.getDate(7));
				product.setProImage(resultSet.getBytes(8));
				product.setProAudio(resultSet.getBytes(9));
				product.setProVideo(resultSet.getBytes(10));

				proList.add(product);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		return proList;
	}

//================================================================================================================================
	public int deleteById(String proId) {
		int result = 0;

		try (Connection connection = DataBaseUtils.createConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("DELETE FROM product1_data where proId=? ")) {
			preparedStatement.setString(1, proId);
			result = preparedStatement.executeUpdate();
			if (result == 1) {
				System.out.println("Deleted");
			} else {
				System.out.println(" Not Deleted");

			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

//=============================================================================================================================
	public product findById(String proId) {
		product product = null;
		try (Connection connection = DataBaseUtils.createConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("select * FROM product1_data where proId=? ")) {
			preparedStatement.setString(1, proId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				product = new product();
				product.setProId(resultSet.getString(1));
				product.setProName(resultSet.getString(2));
				product.setProPrice(resultSet.getDouble(3));
				product.setProBrand(resultSet.getString(4));
				product.setProMadeIn(resultSet.getString(5));
				product.setProManufacturingDate(resultSet.getDate(6));
				product.setProExpiryDate(resultSet.getDate(7));
				product.setProImage(resultSet.getBytes(8));
				product.setProAudio(resultSet.getBytes(9));
				product.setProVideo(resultSet.getBytes(10));

			}

		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return product;
	}

//=========================================================================================================================================
	public int updateByID(product product) throws ClassNotFoundException {
		int count = 0;
		try (Connection connection = DataBaseUtils.createConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement(
					"update product1_data set proName=?, proPrice=?, proBrand=?, proMadeIn=?, proManufacturingDate=?, proExpiryDate=?, proimage=?,proAudio=?,proVideo=? where proId=?");

			preparedStatement.setString(1, product.getProName());

			preparedStatement.setDouble(2, product.getProPrice());
			preparedStatement.setString(3, product.getProBrand());
			preparedStatement.setString(4, product.getProMadeIn());

			preparedStatement.setDate(5, (Date) product.getProManufacturingDate());
			preparedStatement.setDate(6, (Date) product.getProExpiryDate());
			preparedStatement.setBytes(7, product.getProImage());

			preparedStatement.setBytes(8, product.getProAudio());
			preparedStatement.setBytes(9, product.getProVideo());
			preparedStatement.setString(10, product.getProId());

			count = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

//================================================================================================================================================	 
	public List<product> findproductByName(String proName) throws ClassNotFoundException {
		List<product> products = new ArrayList<product>();
		try (Connection connection = DataBaseUtils.createConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("select * FROM product1_data where proName=? ")) {
			preparedStatement.setString(1, proName);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				product product = new product();
				product.setProId(resultSet.getString(1));
				product.setProName(resultSet.getString(2));
				product.setProPrice(resultSet.getDouble(3));
				product.setProBrand(resultSet.getString(4));
				product.setProMadeIn(resultSet.getString(5));
				product.setProManufacturingDate(resultSet.getDate(6));
				product.setProExpiryDate(resultSet.getDate(7));
				product.setProImage(resultSet.getBytes(8));
				product.setProAudio(resultSet.getBytes(9));
				product.setProVideo(resultSet.getBytes(10));
				products.add(product);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return products;
	}
}
