package com.sathya.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.Base64;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.io.IOUtils;

@WebServlet("/UpdateProductServlet")
@MultipartConfig
public class UpdateProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Read the from data
		String proId = request.getParameter("proId");
		String proName = request.getParameter("proName");
		double proPrice = Double.parseDouble(request.getParameter("proPrice"));
		String proBrand = request.getParameter("proBrand");
		String proMadeIn = request.getParameter("proMadeIn");
		Date proManufacturingDate = Date.valueOf(request.getParameter("proManufacturingDate"));
		Date proExpiryDate = Date.valueOf(request.getParameter("proExpiryDate"));
		
		Part imagePart=request.getPart("newproImage");
		Part audioPart=request.getPart("newproAudio");
		Part videoPart=request.getPart("newproVideo");

	

		// Using above details create Product object
		product product = new product();
		product.setProId(proId);
		product.setProName(proName);
		product.setProPrice(proPrice);
		product.setProBrand(proBrand);
		product.setProMadeIn(proMadeIn);
		product.setProManufacturingDate(proManufacturingDate);
		product.setProExpiryDate(proExpiryDate);

		if (imagePart.getSize() != 0) {
			InputStream inputStream = imagePart.getInputStream();
			byte[] proImage = IOUtils.toByteArray(inputStream);
			product.setProImage(proImage);
		} else {
			String S = request.getParameter("oldProImage");
			byte[] proImage = Base64.getDecoder().decode(S);
			product.setProImage(proImage);
			
			if (videoPart.getSize() != 0) {
				InputStream inputStream = imagePart.getInputStream();
				byte[] proVideo = IOUtils.toByteArray(inputStream);
				product.setProImage(proVideo);
				System.out.println("If");
			} else {
				String S1 = request.getParameter("oldProVideo");
				byte[] proVideo = Base64.getDecoder().decode(S1);
				product.setProVideo(proVideo);
				
				if (audioPart.getSize() != 0) {
					InputStream inputStream = imagePart.getInputStream();
					byte[] proAudio = IOUtils.toByteArray(inputStream);
					product.setProAudio(proAudio);
				} else {
					String S12 = request.getParameter("oldProAudio");
					byte[] proAudio = Base64.getDecoder().decode(S12);
					product.setProAudio(proAudio);
		}
		// Giving the product object to ProductDao layer save method to save the data :-
		// into database
	       ProductDao productDao=new ProductDao();
	       int result=0;
		try {
			result = productDao.updateByID(product);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       
	       request.setAttribute("updateResult",result);
	    
	        if (result==1) {
	    	   RequestDispatcher dispatcher=request.getRequestDispatcher("ProductList.jsp");
	    	   dispatcher.forward(request, response);
	       }
	         else {
	        	  
	  	    	   RequestDispatcher dispatcher=request.getRequestDispatcher("edit-form.jsp");
	  	    	   dispatcher.forward(request, response);
	         }
	            
	         }
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		}	
		}

